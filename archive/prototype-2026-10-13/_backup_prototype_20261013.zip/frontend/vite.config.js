import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],

  // Cấu hình build cho Production
  build: {
    outDir: 'dist',
    sourcemap: false,       // Tắt sourcemap để bảo vệ code
    chunkSizeWarningLimit: 1000,
    rollupOptions: {
      output: {
        // Vite 8 (rolldown) yêu cầu manualChunks là function
        manualChunks(id) {
          if (id.includes('node_modules/react') || id.includes('node_modules/react-dom')) {
            return 'vendor';
          }
          if (id.includes('node_modules/axios')) {
            return 'http';
          }
        },
        // Đặt tên file theo nội dung để cache tốt hơn
        chunkFileNames: 'assets/js/[name]-[hash].js',
        entryFileNames: 'assets/js/[name]-[hash].js',
        assetFileNames: 'assets/[ext]/[name]-[hash].[ext]',
      },
    },
  },

  // Dev server proxy → tránh CORS khi gọi /api/* trong môi trường dev
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:5000',
        changeOrigin: true,
      },
    },
  },

  // Preview server (sau khi build)
  preview: {
    port: 4173,
  },
});
