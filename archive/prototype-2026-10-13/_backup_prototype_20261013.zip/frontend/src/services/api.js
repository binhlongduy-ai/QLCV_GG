import axios from 'axios';

const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

const apiClient = axios.create({
  baseURL: BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Interceptor: tự động đính kèm token nếu có
apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// ─── AUTH ────────────────────────────────────────────────────────────────────
export const login = async (email, password) => {
  try {
    const res = await apiClient.post('/auth/login', { email, password });
    if (res.data.token) {
      localStorage.setItem('token', res.data.token);
    }
    return res.data;
  } catch (err) {
    throw err.response?.data || { message: 'Lỗi kết nối server' };
  }
};

export const logout = () => {
  localStorage.removeItem('token');
};

// ─── TASKS ────────────────────────────────────────────────────────────────────
export const getTasks = async () => {
  const res = await apiClient.get('/tasks');
  return res.data.data;
};

export const createTask = async (taskData) => {
  const res = await apiClient.post('/tasks', taskData);
  return res.data.data;
};

export const updateTask = async (id, taskData) => {
  const res = await apiClient.put(`/tasks/${id}`, taskData);
  return res.data.data;
};

export const deleteTask = async (id) => {
  const res = await apiClient.delete(`/tasks/${id}`);
  return res.data;
};

// ─── CUSTOMERS ────────────────────────────────────────────────────────────────
export const getCustomers = async () => {
  const res = await apiClient.get('/customers');
  return res.data.data;
};

export default apiClient;
