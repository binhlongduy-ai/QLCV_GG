// Mô phỏng API gọi lên Backend (Thay thế cho google.script.run cũ)

const MOCK_DELAY = 600; // Mô phỏng độ trễ mạng (ms)

const MOCK_DATA = {
  currentUser: {
    email: 'admin@example.com',
    name: 'Admin User',
    role: 'Admin',
    avatar: 'AD'
  },
  stats: {
    total: 24,
    completed: 12,
    inProgress: 8,
    pending: 4
  },
  tasks: [
    { id: 'CV001', title: 'Thẩm định hồ sơ Vay vốn KH A', status: 'Đang Xử Lý', priority: 'Cao', assignee: 'CBTD1', deadline: '2026-10-15' },
    { id: 'CV002', title: 'Kiểm tra tài sản đảm bảo KH B', status: 'Hoàn Thành', priority: 'Bình Thường', assignee: 'CBTD2', deadline: '2026-10-10' },
    { id: 'CV003', title: 'Thu thập hồ sơ tài chính KH C', status: 'Mới Giao', priority: 'Cao', assignee: 'CBTD1', deadline: '2026-10-20' },
  ],
  customers: [
    { id: 'KH001', name: 'Nguyễn Văn A', type: 'Cá Nhân', phone: '0901234567' },
    { id: 'KH002', name: 'Công ty TNHH B', type: 'Doanh Nghiệp', phone: '0909876543' },
  ]
};

export const mockApi = {
  // Lấy thông tin User hiện tại
  getCurrentUser: () => new Promise(resolve => setTimeout(() => resolve(MOCK_DATA.currentUser), MOCK_DELAY)),
  
  // Thống kê Dashboard
  getDashboardStats: () => new Promise(resolve => setTimeout(() => resolve(MOCK_DATA.stats), MOCK_DELAY)),

  // Lấy danh sách Công việc
  getTasks: () => new Promise(resolve => setTimeout(() => resolve(MOCK_DATA.tasks), MOCK_DELAY)),

  // Lấy danh sách Khách hàng
  getCustomers: () => new Promise(resolve => setTimeout(() => resolve(MOCK_DATA.customers), MOCK_DELAY)),
};
