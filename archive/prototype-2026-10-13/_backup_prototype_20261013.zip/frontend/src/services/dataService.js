/**
 * dataService.js — Unified data service layer
 *
 * Module này tự detect backend một lần khi khởi tạo (ping localhost:5000).
 * Kết quả được cache trong _initPromise, tránh ping nhiều lần.
 *
 * Pages chỉ cần import và gọi hàm — không cần biết nguồn là mock hay real.
 *
 * Ví dụ:
 *   import { getTasks, getMode } from '../services/dataService';
 *   const tasks = await getTasks();
 */

import * as api from './api';
import { mockApi } from './mockApi';

// ─── Auto-detect backend ───────────────────────────────────────────────────────

let _isReal = false;

/**
 * Promise khởi tạo — chạy đúng một lần khi module được import lần đầu.
 * Mọi hàm export đều await promise này trước khi gọi api/mock.
 */
const _initPromise = fetch('http://localhost:5000/', { method: 'GET' })
  .then(() => {
    _isReal = true;
    console.info('✅ [dataService] Kết nối Backend API thành công (localhost:5000)');
  })
  .catch(() => {
    _isReal = false;
    console.warn('⚠️ [dataService] Backend chưa bật — sử dụng Mock Data');
  });

// ─── Public API ───────────────────────────────────────────────────────────────

/**
 * Trả về mode hiện tại: 'real' hoặc 'mock'.
 * Đảm bảo đã init xong trước khi đọc.
 */
export const getMode = async () => {
  await _initPromise;
  return _isReal ? 'real' : 'mock';
};

/**
 * Lấy danh sách công việc.
 * Nguồn: GET /api/tasks (khi backend bật) hoặc mock data.
 */
export const getTasks = async () => {
  await _initPromise;
  return _isReal ? api.getTasks() : mockApi.getTasks();
};

/**
 * Lấy danh sách khách hàng.
 * Nguồn: GET /api/customers (khi backend bật) hoặc mock data.
 */
export const getCustomers = async () => {
  await _initPromise;
  return _isReal ? api.getCustomers() : mockApi.getCustomers();
};

/**
 * Lấy thống kê Dashboard.
 * TODO: Backend chưa có endpoint /api/dashboard/stats — luôn dùng mock cho đến khi được bổ sung.
 */
export const getDashboardStats = async () => {
  await _initPromise;
  // Khi backend có endpoint, thay bằng: return _isReal ? api.getDashboardStats() : mockApi.getDashboardStats();
  return mockApi.getDashboardStats();
};
