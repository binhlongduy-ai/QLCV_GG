import React from 'react';

const Sidebar = ({ activeTab, setActiveTab, user }) => {
  return (
    <nav className="sidebar">
      <div className="sidebar-brand">
        <div className="brand-icon">⚡</div>
        <div className="brand-text">
          QLCV CBTD
          <small>Phiên bản 2.0</small>
        </div>
      </div>
      
      <div className="sidebar-nav">
        <div className="nav-label">Menu Chính</div>
        <div 
          className={`nav-item ${activeTab === 'dashboard' ? 'active' : ''}`}
          onClick={() => setActiveTab('dashboard')}
        >
          <span className="nav-icon">📊</span>
          Tổng Quan
        </div>
        <div 
          className={`nav-item ${activeTab === 'tasks' ? 'active' : ''}`}
          onClick={() => setActiveTab('tasks')}
        >
          <span className="nav-icon">📋</span>
          Công Việc
        </div>
        <div 
          className={`nav-item ${activeTab === 'customers' ? 'active' : ''}`}
          onClick={() => setActiveTab('customers')}
        >
          <span className="nav-icon">👥</span>
          Khách Hàng
        </div>
      </div>
      
      <div className="sidebar-footer">
        <div className="user-info">
          <div className="user-avatar">{user?.avatar || 'U'}</div>
          <div className="user-details">
            <div className="user-name">{user?.name || 'Loading...'}</div>
            <div className="user-role">{user?.role || ''}</div>
          </div>
        </div>
        <button className="btn-logout">Đăng Xuất</button>
      </div>
    </nav>
  );
};

export default Sidebar;
