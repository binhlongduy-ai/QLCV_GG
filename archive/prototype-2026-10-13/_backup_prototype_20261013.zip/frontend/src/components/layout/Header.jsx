import React from 'react';

const Header = ({ title, subtitle, apiMode }) => {
  return (
    <header className="page-header">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <h2>{title}</h2>
          {subtitle && <p>{subtitle}</p>}
        </div>
        {/* Chỉ báo chế độ API */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{
            fontSize: '0.78rem',
            fontWeight: 600,
            padding: '4px 10px',
            borderRadius: '20px',
            background: apiMode === 'real' ? 'var(--success-light)' : 'var(--warning-light)',
            color: apiMode === 'real' ? 'var(--success)' : 'var(--warning)',
            border: `1px solid ${apiMode === 'real' ? 'var(--success)' : 'var(--warning)'}22`,
          }}>
            {apiMode === 'real' ? '🟢 Backend Live' : '🟡 Mock Data'}
          </span>
        </div>
      </div>
    </header>
  );
};

export default Header;
