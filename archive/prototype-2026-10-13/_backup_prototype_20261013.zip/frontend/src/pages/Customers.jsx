import React, { useEffect, useState } from 'react';
import { mockApi } from '../services/mockApi';

const Customers = () => {
  const [customers, setCustomers] = useState([]);

  useEffect(() => {
    mockApi.getCustomers().then(setCustomers);
  }, []);

  return (
    <div className="card">
      <div style={{ padding: '24px' }}>
        <h3 style={{ color: 'white', marginBottom: '16px' }}>Danh Sách Khách Hàng</h3>
        
        <div className="table-responsive">
          <table className="data-table">
            <thead>
              <tr>
                <th>Mã KH</th>
                <th>Tên Khách Hàng</th>
                <th>Phân Loại</th>
                <th>Số Điện Thoại</th>
              </tr>
            </thead>
            <tbody>
              {customers.length === 0 ? (
                <tr>
                  <td colSpan="4" style={{ textAlign: 'center', color: 'var(--text-secondary)' }}>
                    Đang tải dữ liệu...
                  </td>
                </tr>
              ) : (
                customers.map(customer => (
                  <tr key={customer.id}>
                    <td style={{ color: 'var(--primary)' }}>{customer.id}</td>
                    <td style={{ color: 'white', fontWeight: 500 }}>{customer.name}</td>
                    <td>
                      <span className="status-badge" style={{ background: 'var(--primary-surface)', color: 'var(--primary-light)' }}>
                        {customer.type}
                      </span>
                    </td>
                    <td>{customer.phone}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Customers;
