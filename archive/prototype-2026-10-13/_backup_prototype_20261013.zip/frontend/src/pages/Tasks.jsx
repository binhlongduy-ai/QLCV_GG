import React, { useEffect, useState } from 'react';
import { mockApi } from '../services/mockApi';
import { getTasks as getTasksApi } from '../services/api';

const STATUS_MAP = {
  'pending': { label: 'Mới Giao', cls: 'moi-giao' },
  'in-progress': { label: 'Đang Xử Lý', cls: 'dang-xu-ly' },
  'completed': { label: 'Hoàn Thành', cls: 'hoan-thanh' },
  // legacy mock statuses
  'Mới Giao': { label: 'Mới Giao', cls: 'moi-giao' },
  'Đang Xử Lý': { label: 'Đang Xử Lý', cls: 'dang-xu-ly' },
  'Chờ Duyệt': { label: 'Chờ Duyệt', cls: 'cho-duyet' },
  'Hoàn Thành': { label: 'Hoàn Thành', cls: 'hoan-thanh' },
};

const PRIORITY_MAP = {
  'high': { label: 'Cao', cls: 'mucdo-uutien' },
  'medium': { label: 'Trung Bình', cls: 'mucdo-binhthuong' },
  'low': { label: 'Thấp', cls: 'mucdo-thap' },
  'Cao': { label: 'Cao', cls: 'mucdo-uutien' },
  'Thường': { label: 'Thường', cls: 'mucdo-binhthuong' },
};

const Tasks = ({ apiMode }) => {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    setLoading(true);
    setError(null);

    const fetchFn = apiMode === 'real'
      ? getTasksApi()
      : mockApi.getTasks();

    fetchFn
      .then(setTasks)
      .catch(() => setError('Không tải được dữ liệu công việc'))
      .finally(() => setLoading(false));
  }, [apiMode]);

  const getStatusBadge = (status) => {
    const s = STATUS_MAP[status] || { label: status, cls: 'mucdo-khac' };
    return <span className={`status-badge ${s.cls}`}>{s.label}</span>;
  };

  const getPriorityBadge = (priority) => {
    const p = PRIORITY_MAP[priority] || { label: priority, cls: 'mucdo-khac' };
    return <span className={`status-badge ${p.cls}`}>{p.label}</span>;
  };

  return (
    <div className="card">
      <div className="card-header">
        <h3>Danh Sách Công Việc</h3>
        {apiMode === 'real' && (
          <span className="status-badge hoan-thanh" style={{ fontSize: '0.75rem' }}>
            🟢 Live API
          </span>
        )}
      </div>

      <div style={{ padding: '0 0 24px' }}>
        {loading && (
          <p style={{ padding: '24px', color: 'var(--text-secondary)', textAlign: 'center' }}>
            Đang tải...
          </p>
        )}
        {error && (
          <p style={{ padding: '24px', color: 'var(--danger)', textAlign: 'center' }}>{error}</p>
        )}
        {!loading && !error && (
          <div className="table-responsive">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Mã CV</th>
                  <th>Tiêu Đề</th>
                  <th>Người Nhận</th>
                  <th>Mức Độ</th>
                  <th>Thời Hạn</th>
                  <th>Trạng Thái</th>
                </tr>
              </thead>
              <tbody>
                {tasks.length === 0 ? (
                  <tr>
                    <td colSpan="6" style={{ textAlign: 'center', color: 'var(--text-secondary)' }}>
                      Không có dữ liệu
                    </td>
                  </tr>
                ) : (
                  tasks.map(task => (
                    <tr key={task.id}>
                      <td style={{ color: 'var(--primary)', fontWeight: 600 }}>{task.id}</td>
                      <td style={{ fontWeight: 500 }}>{task.title}</td>
                      <td>{task.assignee}</td>
                      <td>{getPriorityBadge(task.priority)}</td>
                      <td>{task.dueDate || task.deadline}</td>
                      <td>{getStatusBadge(task.status)}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default Tasks;
