import React, { useEffect, useState } from 'react';
import { getDashboardStats } from '../services/dataService';

const Dashboard = () => {
  const [stats, setStats] = useState(null);

  useEffect(() => {
    getDashboardStats().then(setStats);
  }, []);

  if (!stats) return <p style={{ color: 'var(--text-secondary)' }}>Đang tải dữ liệu...</p>;

  return (
    <div>
      <div className="stats-grid">
        <div className="stat-card blue">
          <div className="stat-icon">📋</div>
          <div className="stat-value">{stats.total}</div>
          <div className="stat-label">Tổng Công Việc</div>
        </div>
        <div className="stat-card green">
          <div className="stat-icon">✅</div>
          <div className="stat-value">{stats.completed}</div>
          <div className="stat-label">Hoàn Thành</div>
        </div>
        <div className="stat-card yellow">
          <div className="stat-icon">⏳</div>
          <div className="stat-value">{stats.inProgress}</div>
          <div className="stat-label">Đang Xử Lý</div>
        </div>
        <div className="stat-card red">
          <div className="stat-icon">⚠️</div>
          <div className="stat-value">{stats.pending}</div>
          <div className="stat-label">Chờ Duyệt</div>
        </div>
      </div>

      <div className="card">
        <div style={{ padding: '24px' }}>
          <h3 style={{ color: 'white', marginBottom: '16px' }}>Hoạt động gần đây</h3>
          <p style={{ color: 'var(--text-secondary)' }}>Tính năng này sẽ sớm được hoàn thiện.</p>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
