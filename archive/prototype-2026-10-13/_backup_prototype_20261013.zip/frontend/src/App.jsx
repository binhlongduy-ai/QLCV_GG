import React, { useState, useEffect } from 'react';
import './index.css';

// Components
import Sidebar from './components/layout/Sidebar';
import Header from './components/layout/Header';

// Pages
import Dashboard from './pages/Dashboard';
import Tasks from './pages/Tasks';
import Customers from './pages/Customers';

// Services — dùng API thật, fallback về mock nếu backend chưa bật
import * as api from './services/api';
import { mockApi } from './services/mockApi';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [user, setUser] = useState(null);
  const [apiMode, setApiMode] = useState('mock'); // 'real' | 'mock'

  useEffect(() => {
    // Kiểm tra backend có đang chạy không
    fetch('http://localhost:5000/')
      .then(() => {
        setApiMode('real');
        console.info('✅ Đã kết nối Backend API (localhost:5000)');
      })
      .catch(() => {
        setApiMode('mock');
        console.warn('⚠️ Backend chưa bật — dùng Mock Data');
      });

    // Load user ban đầu (mock vì chưa có login page)
    mockApi.getCurrentUser().then(setUser);
  }, []);

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <Dashboard apiMode={apiMode} />;
      case 'tasks':     return <Tasks apiMode={apiMode} />;
      case 'customers': return <Customers apiMode={apiMode} />;
      default:          return <Dashboard apiMode={apiMode} />;
    }
  };

  const getPageTitle = () => {
    switch (activeTab) {
      case 'dashboard': return { title: 'Tổng Quan', subtitle: 'Bảng điều khiển hệ thống' };
      case 'tasks':     return { title: 'Quản Lý Công Việc', subtitle: 'Danh sách và tiến độ công việc' };
      case 'customers': return { title: 'Khách Hàng', subtitle: 'Danh mục khách hàng tín dụng' };
      default:          return { title: 'Tổng Quan', subtitle: '' };
    }
  };

  const { title, subtitle } = getPageTitle();

  return (
    <div className="app-layout active">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} user={user} />

      <main className="main-content">
        <Header title={title} subtitle={subtitle} apiMode={apiMode} />

        <div className="page-body">
          {renderContent()}
        </div>
      </main>
    </div>
  );
}

export default App;
