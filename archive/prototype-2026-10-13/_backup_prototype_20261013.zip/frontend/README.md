# QLCV CBTD - Ứng Dụng Quản Lý Công Việc Phiên Bản 2.0

Chào mừng đến với phiên bản tái thiết kế của hệ thống Quản Lý Công Việc dành cho Cán Bộ Tín Dụng.
Dự án này sử dụng kiến trúc Frontend hiện đại với **Vite**, **React**, và **Vanilla CSS (Glassmorphism Dark Mode)**.

## 🌟 Điểm nổi bật
- **Giao diện Premium:** 100% Dark Mode kết hợp hiệu ứng kính (Glassmorphism) sang trọng.
- **Tốc độ cao:** Sử dụng Vite cho quá trình phát triển (HMR tức thì) và tối ưu build production.
- **Kiến trúc Component:** Mã nguồn được tổ chức theo tiêu chuẩn, tách biệt rõ ràng UI và Logic.
- **Sẵn sàng cho API:** Đã tích hợp sẵn `mockApi` để mô phỏng dữ liệu trong lúc chờ Backend chính thức.

## 📂 Cấu trúc thư mục

```text
src/
├── assets/         # Hình ảnh, font chữ tĩnh
├── components/     # Các UI Component dùng chung
│   ├── layout/     # (Sidebar, Header, MainLayout)
│   └── ui/         # (Card, StatCard, Button, Badge)
├── pages/          # Các trang chính (Dashboard, Tasks, Customers)
├── services/       # Nơi gọi API, kết nối Backend (chứa mockApi.js)
├── index.css       # File CSS tổng chứa hệ thống biến và style toàn cục
└── App.jsx         # Component gốc, cấu hình điều hướng (Routing)
```

## 🚀 Hướng dẫn khởi chạy

Cài đặt các gói phụ thuộc (nếu chưa cài):
```bash
npm install
```

Khởi chạy máy chủ phát triển (Development Server):
```bash
npm run dev
```

Mở trình duyệt và truy cập vào đường dẫn được hiển thị (thường là `http://localhost:5173`).

## 🛠 Lộ trình tiếp theo (Pha 4 & 5)
- Tích hợp **React Router** để quản lý URL (thay vì state đơn giản).
- Đấu nối với **Backend thực tế** (Node.js/Express) thay cho Mock API.
- Cài đặt hệ thống phân quyền (AuthGuard).
