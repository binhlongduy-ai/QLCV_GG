const login = (req, res) => {
  const { email, password } = req.body;
  if (email === 'admin@domain.com' && password === 'admin') {
    res.status(200).json({ 
      success: true, 
      token: 'mock-jwt-token-12345',
      user: { id: 1, name: 'Admin', email } 
    });
  } else {
    res.status(401).json({ success: false, message: 'Invalid credentials' });
  }
};

module.exports = {
  login
};
