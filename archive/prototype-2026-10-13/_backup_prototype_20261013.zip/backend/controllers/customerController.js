let customers = [
  { id: 'C001', name: 'Nguyễn Văn A', phone: '0901234567', type: 'Cá nhân', status: 'active', loanAmount: 500000000 },
  { id: 'C002', name: 'Trần Thị B', phone: '0912345678', type: 'Cá nhân', status: 'warning', loanAmount: 150000000 },
  { id: 'C003', name: 'Công ty TNHH XYZ', phone: '0283456789', type: 'Doanh nghiệp', status: 'active', loanAmount: 2000000000 },
];

const getAllCustomers = (req, res) => {
  res.status(200).json({ success: true, data: customers });
};

module.exports = {
  getAllCustomers
};
