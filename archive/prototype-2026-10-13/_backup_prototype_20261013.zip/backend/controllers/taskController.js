// In-memory data store for Phase 4 prototype
let tasks = [
  { id: 'T001', title: 'Thẩm định hồ sơ Vay vốn Nguyễn Văn A', status: 'pending', priority: 'high', assignee: 'CB01', dueDate: '2026-10-15' },
  { id: 'T002', title: 'Báo cáo định kỳ tháng 10', status: 'in-progress', priority: 'medium', assignee: 'CB02', dueDate: '2026-10-12' },
  { id: 'T003', title: 'Thu hồi nợ thẻ tín dụng Trần Thị B', status: 'completed', priority: 'high', assignee: 'CB01', dueDate: '2026-10-05' },
  { id: 'T004', title: 'Kiểm tra TSĐB khoản vay Doanh nghiệp', status: 'pending', priority: 'low', assignee: 'CB03', dueDate: '2026-10-20' },
];

const getAllTasks = (req, res) => {
  res.status(200).json({ success: true, data: tasks });
};

const createTask = (req, res) => {
  const newTask = {
    id: `T00${tasks.length + 1}`,
    ...req.body,
    status: req.body.status || 'pending'
  };
  tasks.push(newTask);
  res.status(201).json({ success: true, data: newTask });
};

const updateTask = (req, res) => {
  const { id } = req.params;
  const index = tasks.findIndex(t => t.id === id);
  if (index === -1) {
    return res.status(404).json({ success: false, message: 'Task not found' });
  }
  tasks[index] = { ...tasks[index], ...req.body };
  res.status(200).json({ success: true, data: tasks[index] });
};

const deleteTask = (req, res) => {
  const { id } = req.params;
  tasks = tasks.filter(t => t.id !== id);
  res.status(200).json({ success: true, message: 'Task deleted' });
};

module.exports = {
  getAllTasks,
  createTask,
  updateTask,
  deleteTask
};
